document.getElementById('button2embedorg').addEventListener('click', function() {
  chrome.tabs.query({active: true, lastFocusedWindow: true}, tabs => {
    let url = tabs[0].url;
    const spliturl = url.split('/');
    window.open('https://2embed.org/embed/movie?imdb=' + spliturl[4]).focus();
  }); 
});

document.getElementById('button2embedbiz').addEventListener('click', function() {
  chrome.tabs.query({active: true, lastFocusedWindow: true}, tabs => {
    let url = tabs[0].url;
    const spliturl = url.split('/');
    window.open('https://2embed.biz/embed/' + spliturl[4]).focus();
  }); 
});